# IND SaaS Platform

This is a self-hosted SaaS platform supporting .ind domains and Bitcoin billing.