import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | Date): string {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function formatRelativeTime(date: string | Date): string {
  const now = new Date();
  const target = new Date(date);
  const diffInSeconds = Math.floor((now.getTime() - target.getTime()) / 1000);

  if (diffInSeconds < 60) {
    return "just now";
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60);
    return `${minutes} minute${minutes > 1 ? "s" : ""} ago`;
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600);
    return `${hours} hour${hours > 1 ? "s" : ""} ago`;
  } else {
    const days = Math.floor(diffInSeconds / 86400);
    return `${days} day${days > 1 ? "s" : ""} ago`;
  }
}

export function validateIndDomain(domain: string): { valid: boolean; message: string } {
  if (!domain) {
    return { valid: false, message: "Domain is required" };
  }

  if (!domain.endsWith('.ind')) {
    return { valid: false, message: "Only .ind domains are allowed" };
  }

  // Basic domain validation
  const domainPattern = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?\.ind$/i;
  if (!domainPattern.test(domain)) {
    return { valid: false, message: "Invalid domain format" };
  }

  if (domain.length > 63) {
    return { valid: false, message: "Domain name too long" };
  }

  return { valid: true, message: "Valid .ind domain" };
}

export function generateSubdomain(domain: string): string {
  return domain.replace('.ind', '');
}

export function formatBitcoinAmount(amount: string | number): string {
  const btcAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  return `${btcAmount.toFixed(8)} BTC`;
}

export function formatCurrency(amount: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
  }).format(amount);
}
