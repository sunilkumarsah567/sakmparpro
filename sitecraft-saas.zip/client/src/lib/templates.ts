export interface Template {
  id: string;
  name: string;
  description: string;
  category: string;
  previewImage?: string;
  content: any;
}

export const templates: Template[] = [
  {
    id: "portfolio",
    name: "Portfolio",
    description: "Showcase your work and skills",
    category: "Creative",
    content: {
      sections: [
        {
          type: "hero",
          title: "Your Name",
          subtitle: "Professional Title",
          description: "Brief introduction about yourself",
          cta: "View My Work"
        },
        {
          type: "portfolio",
          title: "Recent Projects",
          items: [
            { title: "Project 1", description: "Project description", image: "" },
            { title: "Project 2", description: "Project description", image: "" },
            { title: "Project 3", description: "Project description", image: "" }
          ]
        },
        {
          type: "contact",
          title: "Get In Touch",
          email: "your.email@example.com",
          social: []
        }
      ]
    }
  },
  {
    id: "blog",
    name: "Blog",
    description: "Share your thoughts and stories",
    category: "Content",
    content: {
      sections: [
        {
          type: "header",
          title: "My Blog",
          subtitle: "Thoughts, stories, and ideas"
        },
        {
          type: "posts",
          title: "Latest Posts",
          items: [
            { title: "First Post", excerpt: "This is my first blog post...", date: "2024-01-01" },
            { title: "Second Post", excerpt: "Another interesting article...", date: "2024-01-02" }
          ]
        }
      ]
    }
  },
  {
    id: "landing",
    name: "Landing Page",
    description: "Convert visitors with a focused page",
    category: "Business",
    content: {
      sections: [
        {
          type: "hero",
          title: "Your Product Name",
          subtitle: "Solve customer problems with ease",
          description: "Detailed description of your product or service",
          cta: "Get Started"
        },
        {
          type: "features",
          title: "Features",
          items: [
            { title: "Feature 1", description: "Feature description" },
            { title: "Feature 2", description: "Feature description" },
            { title: "Feature 3", description: "Feature description" }
          ]
        },
        {
          type: "cta",
          title: "Ready to get started?",
          description: "Join thousands of satisfied customers",
          button: "Sign Up Now"
        }
      ]
    }
  },
  {
    id: "ecommerce",
    name: "Online Store",
    description: "Sell products online",
    category: "E-commerce",
    content: {
      sections: [
        {
          type: "header",
          title: "Your Store",
          subtitle: "Quality products for you"
        },
        {
          type: "products",
          title: "Featured Products",
          items: [
            { name: "Product 1", price: "$99", image: "" },
            { name: "Product 2", price: "$149", image: "" },
            { name: "Product 3", price: "$199", image: "" }
          ]
        },
        {
          type: "about",
          title: "About Our Store",
          description: "We provide high-quality products with excellent customer service."
        }
      ]
    }
  }
];

export function getTemplates(): Template[] {
  return templates;
}

export function getTemplate(id: string): Template | undefined {
  return templates.find(template => template.id === id);
}
