import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Laptop, Eye, Edit, Trash2, ExternalLink } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";

interface SiteCardProps {
  site: any;
  isProActive: boolean;
  onEdit: () => void;
}

export function SiteCard({ site, isProActive, onEdit }: SiteCardProps) {
  const { toast } = useToast();

  const deleteSiteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", `/api/sites/${site.id}`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sites"] });
      toast({
        title: "Site deleted",
        description: "Your site has been deleted successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to delete site",
        description: error.message,
      });
    },
  });

  const publishSiteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PUT", `/api/sites/${site.id}`, { 
        isPublished: true,
        isActive: true 
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sites"] });
      toast({
        title: "Site published!",
        description: "Your site is now live.",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to publish site",
        description: error.message,
      });
    },
  });

  const getStatusColor = () => {
    if (site.isActive) return "bg-green-100 text-green-800 hover:bg-green-100";
    if (site.isPublished) return "bg-blue-100 text-blue-800 hover:bg-blue-100";
    return "bg-orange-100 text-orange-800 hover:bg-orange-100";
  };

  const getStatusText = () => {
    if (site.isActive) return "Active";
    if (site.isPublished) return "Published";
    return "Draft";
  };

  const canPublish = isProActive && site.domain.endsWith('.ind') && !site.isPublished;

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mr-3">
              <Laptop className="text-primary h-5 w-5" />
            </div>
            <div>
              <h4 className="font-semibold text-secondary">{site.title}</h4>
              <p className="text-sm text-neutral-500">{site.domain}</p>
            </div>
          </div>
          <Badge className={getStatusColor()}>
            {getStatusText()}
          </Badge>
        </div>
        
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-neutral-500">Template</span>
            <span className="font-medium capitalize">{site.templateId}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-neutral-500">Last Updated</span>
            <span className="font-medium">
              {new Date(site.updatedAt).toLocaleDateString()}
            </span>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={onEdit}
          >
            <Edit className="w-4 h-4 mr-1" />
            Edit
          </Button>
          
          {site.isActive ? (
            <Button 
              size="sm" 
              className="flex-1"
              onClick={() => window.open(`https://${site.domain}`, '_blank')}
            >
              <ExternalLink className="w-4 h-4 mr-1" />
              Visit
            </Button>
          ) : canPublish ? (
            <Button 
              size="sm" 
              className="flex-1"
              onClick={() => publishSiteMutation.mutate()}
              disabled={publishSiteMutation.isPending}
            >
              {publishSiteMutation.isPending ? "Publishing..." : "Publish"}
            </Button>
          ) : (
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              disabled
            >
              <Eye className="w-4 h-4 mr-1" />
              Preview
            </Button>
          )}
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => deleteSiteMutation.mutate()}
            disabled={deleteSiteMutation.isPending}
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
