import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getTemplates } from "@/lib/templates";
import { Check } from "lucide-react";

interface TemplateSelectorProps {
  selectedTemplate: string;
  onSelectTemplate: (templateId: string) => void;
  compact?: boolean;
}

export function TemplateSelector({ selectedTemplate, onSelectTemplate, compact = false }: TemplateSelectorProps) {
  const templates = getTemplates();

  if (compact) {
    return (
      <div className="grid grid-cols-2 gap-3">
        {templates.map((template) => (
          <div
            key={template.id}
            className={`border rounded-lg p-3 cursor-pointer transition-colors ${
              selectedTemplate === template.id
                ? "border-primary bg-primary/5"
                : "border-neutral-200 bg-white hover:border-neutral-300"
            }`}
            onClick={() => onSelectTemplate(template.id)}
          >
            <div className="relative">
              <div className="w-full h-16 bg-gradient-to-br from-neutral-100 to-neutral-200 rounded mb-2"></div>
              {selectedTemplate === template.id && (
                <div className="absolute top-1 right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                  <Check className="w-3 h-3 text-white" />
                </div>
              )}
            </div>
            <div className="text-xs font-medium text-neutral-600">{template.name}</div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Choose a Template</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates.map((template) => (
          <Card
            key={template.id}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedTemplate === template.id
                ? "ring-2 ring-primary ring-offset-2"
                : ""
            }`}
            onClick={() => onSelectTemplate(template.id)}
          >
            <CardContent className="p-4">
              <div className="relative mb-3">
                <div className="w-full h-32 bg-gradient-to-br from-neutral-100 to-neutral-200 rounded">
                  {/* Template preview placeholder */}
                  <div className="p-3 text-xs">
                    <div className="bg-white rounded p-2 mb-2">
                      <div className="h-2 bg-neutral-300 rounded mb-1"></div>
                      <div className="h-1 bg-neutral-200 rounded"></div>
                    </div>
                    <div className="grid grid-cols-2 gap-1">
                      <div className="h-6 bg-white rounded"></div>
                      <div className="h-6 bg-white rounded"></div>
                    </div>
                  </div>
                </div>
                {selectedTemplate === template.id && (
                  <div className="absolute top-2 right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-sm">{template.name}</h4>
                  <p className="text-xs text-neutral-500">{template.description}</p>
                </div>
                <Badge variant="outline" className="text-xs">
                  {template.category}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
