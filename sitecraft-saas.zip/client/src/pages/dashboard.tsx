import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Navigation } from "@/components/navigation";
import { SiteCard } from "@/components/site-card";
import { TemplateSelector } from "@/components/template-selector";
import { Plus, Crown, Bitcoin, Calendar, AlertCircle } from "lucide-react";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [showCreateSite, setShowCreateSite] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [newSiteName, setNewSiteName] = useState("");
  const [newSiteDomain, setNewSiteDomain] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const { data: sites = [] } = useQuery({
    queryKey: ["/api/sites"],
  });

  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
  });

  const createSiteMutation = useMutation({
    mutationFn: async (siteData: any) => {
      const response = await apiRequest("POST", "/api/sites", siteData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sites"] });
      setShowCreateSite(false);
      setNewSiteName("");
      setNewSiteDomain("");
      setSelectedTemplate("");
      toast({
        title: "Site created successfully!",
        description: "Your new site has been created in draft mode.",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to create site",
        description: error.message,
      });
    },
  });

  const upgradeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/subscription/upgrade", {});
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      setShowUpgrade(false);
      toast({
        title: "Upgrade initiated!",
        description: `Send ${data.paymentInfo.amount} BTC to the provided address to activate Pro plan.`,
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to upgrade",
        description: error.message,
      });
    },
  });

  const confirmPaymentMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/subscription/confirm-payment", {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Payment confirmed!",
        description: "Your Pro plan is now active. You can publish your sites!",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to confirm payment",
        description: error.message,
      });
    },
  });

  const handleCreateSite = () => {
    if (!newSiteName || !newSiteDomain || !selectedTemplate) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please fill in all fields to create a site.",
      });
      return;
    }

    createSiteMutation.mutate({
      title: newSiteName,
      domain: newSiteDomain,
      subdomain: newSiteDomain.replace('.ind', ''),
      templateId: selectedTemplate,
      content: {},
      isPublished: false,
      isActive: false,
    });
  };

  const isProActive = subscription?.status === "active" && subscription?.planType === "pro";
  const isPending = subscription?.status === "pending";

  return (
    <div className="min-h-screen bg-neutral-50">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-secondary">My Websites</h1>
            <p className="text-neutral-500">Manage your .ind domains and Pro subscription</p>
          </div>
          <Dialog open={showCreateSite} onOpenChange={setShowCreateSite}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create New Site
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Website</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="siteName">Site Name</Label>
                    <Input
                      id="siteName"
                      value={newSiteName}
                      onChange={(e) => setNewSiteName(e.target.value)}
                      placeholder="My Portfolio"
                    />
                  </div>
                  <div>
                    <Label htmlFor="domain">Domain</Label>
                    <div className="relative">
                      <Input
                        id="domain"
                        value={newSiteDomain}
                        onChange={(e) => setNewSiteDomain(e.target.value)}
                        placeholder="mysite.ind"
                      />
                    </div>
                    {newSiteDomain && !newSiteDomain.endsWith('.ind') && (
                      <p className="text-sm text-red-500 mt-1">Only .ind domains are allowed</p>
                    )}
                  </div>
                </div>
                
                <TemplateSelector
                  selectedTemplate={selectedTemplate}
                  onSelectTemplate={setSelectedTemplate}
                />
                
                <div className="flex justify-end space-x-3">
                  <Button variant="outline" onClick={() => setShowCreateSite(false)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleCreateSite}
                    disabled={createSiteMutation.isPending}
                  >
                    {createSiteMutation.isPending ? "Creating..." : "Create Site"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Pro Status Banner */}
        {isProActive ? (
          <Card className="bg-gradient-to-r from-accent/10 to-green-100 border-accent/20 mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Crown className="text-accent text-xl mr-3" />
                  <div>
                    <div className="font-semibold text-secondary">Pro Plan Active</div>
                    <div className="text-sm text-neutral-500">
                      Next billing: {subscription?.nextBillingDate ? new Date(subscription.nextBillingDate).toLocaleDateString() : "N/A"}
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  Manage Billing
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : isPending ? (
          <Card className="bg-gradient-to-r from-orange-50 to-yellow-50 border-orange-200 mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Bitcoin className="text-orange-500 text-xl mr-3" />
                  <div>
                    <div className="font-semibold text-secondary">Payment Pending</div>
                    <div className="text-sm text-neutral-500">Complete your Bitcoin payment to activate Pro plan</div>
                  </div>
                </div>
                <Button 
                  onClick={() => confirmPaymentMutation.mutate()}
                  disabled={confirmPaymentMutation.isPending}
                  size="sm"
                >
                  {confirmPaymentMutation.isPending ? "Confirming..." : "Confirm Payment"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="bg-gradient-to-r from-primary/10 to-blue-50 border-primary/20 mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <AlertCircle className="text-primary text-xl mr-3" />
                  <div>
                    <div className="font-semibold text-secondary">Upgrade to Pro</div>
                    <div className="text-sm text-neutral-500">Publish your sites to .ind domains for just $1/month</div>
                  </div>
                </div>
                <Dialog open={showUpgrade} onOpenChange={setShowUpgrade}>
                  <DialogTrigger asChild>
                    <Button>Upgrade Now</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Upgrade to Pro Plan</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="bg-neutral-50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Pro Plan Benefits:</h4>
                        <ul className="text-sm space-y-1 text-neutral-600">
                          <li>• Publish sites to .ind domains</li>
                          <li>• Auto SSL/HTTPS certificates</li>
                          <li>• Custom subdomains</li>
                          <li>• Priority support</li>
                        </ul>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-secondary">$1 / month per site</div>
                        <div className="text-sm text-neutral-500">Paid with Bitcoin</div>
                      </div>
                      <div className="flex justify-end space-x-3">
                        <Button variant="outline" onClick={() => setShowUpgrade(false)}>
                          Cancel
                        </Button>
                        <Button 
                          onClick={() => upgradeMutation.mutate()}
                          disabled={upgradeMutation.isPending}
                        >
                          {upgradeMutation.isPending ? "Processing..." : "Start Upgrade"}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Sites Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sites.map((site: any) => (
            <SiteCard 
              key={site.id} 
              site={site} 
              isProActive={isProActive}
              onEdit={() => setLocation(`/site-builder/${site.id}`)}
            />
          ))}
          
          {sites.length === 0 && (
            <div className="col-span-full text-center py-12">
              <div className="text-neutral-400 mb-4">
                <Crown className="w-16 h-16 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No sites yet</h3>
                <p>Create your first website to get started</p>
              </div>
              <Button onClick={() => setShowCreateSite(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Site
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
