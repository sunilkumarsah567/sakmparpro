import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Box, Globe, Shield, Palette, Users, Container, CheckCircle, XCircle, Star } from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Globe,
      title: ".ind Domain Control",
      description: "Exclusive support for .ind domains with automatic validation and CNAME routing.",
      color: "text-primary"
    },
    {
      icon: Shield,
      title: "Bitcoin Billing",
      description: "Secure recurring payments via BTCPay Server at $1/month per site.",
      color: "text-accent"
    },
    {
      icon: Shield,
      title: "Auto SSL/HTTPS",
      description: "Automatic Let's Encrypt SSL certificates for all .ind domains.",
      color: "text-orange-500"
    },
    {
      icon: Palette,
      title: "Template Library",
      description: "Professional templates for blogs, portfolios, landing pages, and more.",
      color: "text-purple-500"
    },
    {
      icon: Users,
      title: "Admin Dashboard",
      description: "Complete control over user sites, payments, and platform settings.",
      color: "text-blue-500"
    },
    {
      icon: Container,
      title: "Self-Hosted",
      description: "Deploy anywhere with Docker and maintain full control of your platform.",
      color: "text-green-500"
    }
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Navigation */}
      <nav className="bg-white border-b border-neutral-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                <Box className="text-primary text-2xl mr-3" />
                <span className="text-xl font-bold text-secondary">SiteCraft</span>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-neutral-500 hover:text-secondary transition-colors">Features</a>
              <a href="#pricing" className="text-neutral-500 hover:text-secondary transition-colors">Pricing</a>
              <a href="#docs" className="text-neutral-500 hover:text-secondary transition-colors">Docs</a>
              <Button variant="ghost" onClick={() => window.location.href = '/api/login'}>
                Sign In
              </Button>
              <Button onClick={() => window.location.href = '/api/login'}>
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="gradient-bg py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-secondary mb-6">
              Build & Host Websites on <span className="text-primary">.ind</span> Domains
            </h1>
            <p className="text-xl text-neutral-500 mb-8 max-w-3xl mx-auto">
              Create beautiful websites with our self-hosted SaaS platform. Deploy instantly with CNAME routing, 
              secure Bitcoin billing, and professional templates.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={() => window.location.href = '/api/login'}>
                Start Building Free
              </Button>
              <Button variant="outline" size="lg">
                View Demo
              </Button>
            </div>
            
            {/* Dashboard Preview */}
            <div className="mt-12">
              <Card className="max-w-5xl mx-auto shadow-2xl">
                <div className="bg-neutral-100 px-6 py-4 rounded-t-xl border-b border-neutral-200">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <div className="ml-4 text-sm text-neutral-500">dashboard.sitecraft.com</div>
                  </div>
                </div>
                <CardContent className="p-8">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-gradient-to-br from-primary to-blue-600 p-6 rounded-lg text-white">
                      <h3 className="text-lg font-semibold mb-2">Active Sites</h3>
                      <div className="text-3xl font-bold">12</div>
                    </div>
                    <div className="bg-gradient-to-br from-accent to-green-600 p-6 rounded-lg text-white">
                      <h3 className="text-lg font-semibold mb-2">Pro Status</h3>
                      <div className="text-xl font-semibold">Active</div>
                    </div>
                    <div className="bg-gradient-to-br from-orange-400 to-orange-600 p-6 rounded-lg text-white">
                      <h3 className="text-lg font-semibold mb-2">Next Billing</h3>
                      <div className="text-xl font-semibold">15 days</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
              Everything You Need to Host .ind Websites
            </h2>
            <p className="text-xl text-neutral-500 max-w-3xl mx-auto">
              Powerful features designed for modern web hosting with Bitcoin payments and domain control
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 bg-neutral-50">
                <CardContent className="p-8">
                  <div className={`w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4`}>
                    <feature.icon className={`${feature.color} text-xl`} />
                  </div>
                  <h3 className="text-xl font-semibold text-secondary mb-3">{feature.title}</h3>
                  <p className="text-neutral-500">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-secondary mb-4">
              Simple Bitcoin Billing
            </h2>
            <p className="text-xl text-neutral-500">
              Pay $1/month per site with Bitcoin. No hidden fees.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Free Plan */}
              <Card>
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-secondary mb-2">Free</h3>
                    <div className="text-4xl font-bold text-secondary mb-4">$0</div>
                    <p className="text-neutral-500">Perfect for testing and development</p>
                  </div>
                  
                  <ul className="space-y-4 mb-8">
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Site builder access</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>All templates</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Draft mode</span>
                    </li>
                    <li className="flex items-center text-neutral-400">
                      <XCircle className="text-neutral-300 mr-3 h-5 w-5" />
                      <span>Cannot publish to .ind domains</span>
                    </li>
                    <li className="flex items-center text-neutral-400">
                      <XCircle className="text-neutral-300 mr-3 h-5 w-5" />
                      <span>No custom domains</span>
                    </li>
                  </ul>
                  
                  <Button variant="outline" className="w-full" onClick={() => window.location.href = '/api/login'}>
                    Get Started Free
                  </Button>
                </CardContent>
              </Card>
              
              {/* Pro Plan */}
              <Card className="border-2 border-primary relative">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary text-white px-4 py-1">
                    <Star className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
                
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-secondary mb-2">Pro</h3>
                    <div className="text-4xl font-bold text-secondary mb-1">$1</div>
                    <div className="text-neutral-500 mb-4">per site per month</div>
                    <p className="text-neutral-500">Full access to .ind publishing</p>
                  </div>
                  
                  <ul className="space-y-4 mb-8">
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Everything in Free</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Publish to .ind domains</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Auto SSL/HTTPS</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Custom subdomains</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Bitcoin recurring billing</span>
                    </li>
                    <li className="flex items-center">
                      <CheckCircle className="text-accent mr-3 h-5 w-5" />
                      <span>Priority support</span>
                    </li>
                  </ul>
                  
                  <Button className="w-full" onClick={() => window.location.href = '/api/login'}>
                    Start Pro Plan
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center mb-6">
                <Box className="text-primary text-2xl mr-3" />
                <span className="text-2xl font-bold">SiteCraft</span>
              </div>
              <p className="text-neutral-400 mb-6 max-w-md">
                Self-hosted SaaS platform for creating and hosting websites on .ind domains 
                with Bitcoin billing and complete administrative control.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-3 text-neutral-400">
                <li><a href="#features" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Templates</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Self-Hosting</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-3 text-neutral-400">
                <li><a href="#" className="hover:text-white transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API Reference</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Community</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-neutral-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-neutral-400 text-sm">
              © 2024 SiteCraft. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm text-neutral-400 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy</a>
              <a href="#" className="hover:text-white transition-colors">Terms</a>
              <a href="#" className="hover:text-white transition-colors">Security</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
