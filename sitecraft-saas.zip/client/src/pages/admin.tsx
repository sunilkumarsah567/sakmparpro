import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Navigation } from "@/components/navigation";
import { Users, Globe, Crown, Bitcoin, Activity, TrendingUp, Eye } from "lucide-react";

export default function Admin() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const { data: users = [], isLoading: usersLoading } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const { data: sites = [], isLoading: sitesLoading } = useQuery({
    queryKey: ["/api/admin/sites"],
  });

  const { data: payments = [], isLoading: paymentsLoading } = useQuery({
    queryKey: ["/api/admin/payments"],
  });

  const recentActivity = sites.slice(0, 10).map((site: any) => {
    const user = users.find((u: any) => u.id === site.userId);
    return {
      user: user?.email || "Unknown",
      action: site.isPublished ? "Site Published" : "Site Created",
      domain: site.domain,
      status: site.isActive ? "Active" : site.isPublished ? "Published" : "Draft",
      date: new Date(site.updatedAt).toLocaleDateString(),
    };
  });

  if (statsLoading || usersLoading || sitesLoading) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Navigation />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-neutral-600">Loading admin dashboard...</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Navigation />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-secondary">Platform Overview</h1>
            <p className="text-neutral-500">Monitor users, sites, and revenue</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline">
              Export Data
            </Button>
            <Button>
              System Settings
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-primary to-blue-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-80">Total Users</p>
                  <p className="text-3xl font-bold">{stats?.totalUsers || 0}</p>
                  <p className="text-sm opacity-80">+12% this month</p>
                </div>
                <Users className="h-8 w-8 opacity-80" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-accent to-green-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-80">Active Sites</p>
                  <p className="text-3xl font-bold">{stats?.activeSites || 0}</p>
                  <p className="text-sm opacity-80">+8% this month</p>
                </div>
                <Globe className="h-8 w-8 opacity-80" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-orange-400 to-orange-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-80">Pro Users</p>
                  <p className="text-3xl font-bold">{stats?.proUsers || 0}</p>
                  <p className="text-sm opacity-80">71.5% conversion</p>
                </div>
                <Crown className="h-8 w-8 opacity-80" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-500 to-purple-700 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-80">Revenue</p>
                  <p className="text-3xl font-bold">${stats?.monthlyRevenue || 0}</p>
                  <p className="text-sm opacity-80">This month</p>
                </div>
                <Bitcoin className="h-8 w-8 opacity-80" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Domain</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentActivity.map((activity, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{activity.user}</TableCell>
                    <TableCell>{activity.action}</TableCell>
                    <TableCell>{activity.domain}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={activity.status === "Active" ? "default" : activity.status === "Published" ? "secondary" : "outline"}
                        className={
                          activity.status === "Active" 
                            ? "bg-green-100 text-green-800 hover:bg-green-100" 
                            : activity.status === "Published"
                            ? "bg-blue-100 text-blue-800 hover:bg-blue-100"
                            : ""
                        }
                      >
                        {activity.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{activity.date}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Users and Sites Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Users Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Recent Users
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Email</TableHead>
                    <TableHead>Sites</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.slice(0, 5).map((user: any) => {
                    const userSites = sites.filter((site: any) => site.userId === user.id);
                    const hasProSites = userSites.some((site: any) => site.isActive);
                    
                    return (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.email}</TableCell>
                        <TableCell>{userSites.length}</TableCell>
                        <TableCell>
                          <Badge variant={hasProSites ? "default" : "outline"}>
                            {hasProSites ? "Pro" : "Free"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Sites Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2" />
                Recent Sites
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Domain</TableHead>
                    <TableHead>Owner</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sites.slice(0, 5).map((site: any) => {
                    const owner = users.find((u: any) => u.id === site.userId);
                    
                    return (
                      <TableRow key={site.id}>
                        <TableCell className="font-medium">{site.domain}</TableCell>
                        <TableCell>{owner?.email || "Unknown"}</TableCell>
                        <TableCell>
                          <Badge 
                            variant={site.isActive ? "default" : site.isPublished ? "secondary" : "outline"}
                            className={
                              site.isActive 
                                ? "bg-green-100 text-green-800 hover:bg-green-100" 
                                : site.isPublished
                                ? "bg-blue-100 text-blue-800 hover:bg-blue-100"
                                : ""
                            }
                          >
                            {site.isActive ? "Active" : site.isPublished ? "Published" : "Draft"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
