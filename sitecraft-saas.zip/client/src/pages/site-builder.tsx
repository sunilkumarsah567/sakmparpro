import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Navigation } from "@/components/navigation";
import { TemplateSelector } from "@/components/template-selector";
import { ArrowLeft, Eye, Save, Rocket, Heading, FileText, Image, MousePointer } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";

export default function SiteBuilder() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [siteId, setSiteId] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [domain, setDomain] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [content, setContent] = useState<any>({});

  // Extract site ID from URL
  useEffect(() => {
    const path = window.location.pathname;
    const id = path.split('/site-builder/')[1];
    setSiteId(id || null);
  }, []);

  const { data: site, isLoading: siteLoading } = useQuery({
    queryKey: ["/api/sites", siteId],
    queryFn: async () => {
      if (!siteId) return null;
      const response = await fetch(`/api/sites/${siteId}`, { credentials: "include" });
      if (!response.ok) throw new Error("Site not found");
      return response.json();
    },
    enabled: !!siteId,
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
  });

  const updateSiteMutation = useMutation({
    mutationFn: async (updates: any) => {
      const response = await apiRequest("PUT", `/api/sites/${siteId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sites"] });
      toast({
        title: "Site saved successfully!",
        description: "Your changes have been saved.",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to save site",
        description: error.message,
      });
    },
  });

  const publishSiteMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PUT", `/api/sites/${siteId}`, { 
        isPublished: true,
        isActive: true 
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sites"] });
      toast({
        title: "Site published successfully!",
        description: "Your site is now live on the internet.",
      });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Failed to publish site",
        description: error.message,
      });
    },
  });

  // Populate form when site data loads
  useEffect(() => {
    if (site) {
      setTitle(site.title || "");
      setDescription(site.description || "");
      setDomain(site.domain || "");
      setSelectedTemplate(site.templateId || "");
      setContent(site.content || {});
    }
  }, [site]);

  const handleSave = () => {
    updateSiteMutation.mutate({
      title,
      description,
      templateId: selectedTemplate,
      content,
    });
  };

  const handlePublish = () => {
    publishSiteMutation.mutate();
  };

  const isProActive = subscription?.status === "active" && subscription?.planType === "pro";
  const canPublish = isProActive && domain.endsWith('.ind');

  if (siteLoading) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Navigation />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-neutral-600">Loading site builder...</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Navigation />
      
      {/* Builder Toolbar */}
      <div className="bg-white border-b border-neutral-200 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                onClick={() => setLocation('/')}
                className="flex items-center text-neutral-600 hover:text-secondary"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="border-l border-neutral-200 pl-4">
                <span className="font-medium text-secondary">{domain}</span>
                <Badge variant="outline" className="ml-2">
                  {site?.isPublished ? (site?.isActive ? "Active" : "Published") : "Draft"}
                </Badge>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline">
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button 
                variant="outline"
                onClick={handleSave}
                disabled={updateSiteMutation.isPending}
              >
                <Save className="w-4 h-4 mr-2" />
                {updateSiteMutation.isPending ? "Saving..." : "Save"}
              </Button>
              <Button 
                onClick={handlePublish}
                disabled={!canPublish || publishSiteMutation.isPending}
              >
                <Rocket className="w-4 h-4 mr-2" />
                {publishSiteMutation.isPending ? "Publishing..." : "Publish"}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-80 bg-white border-r border-neutral-200 min-h-screen">
          {/* Site Settings */}
          <div className="p-6 border-b border-neutral-200">
            <h3 className="font-semibold text-secondary mb-4">Site Settings</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Site Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="My Awesome Site"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Tell visitors about your site..."
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="domain">Domain</Label>
                <Input
                  id="domain"
                  value={domain}
                  disabled
                  className="bg-neutral-50"
                />
                {domain.endsWith('.ind') ? (
                  <p className="text-xs text-accent mt-1">✓ Valid .ind domain</p>
                ) : (
                  <p className="text-xs text-red-500 mt-1">✗ Only .ind domains allowed</p>
                )}
              </div>
            </div>
          </div>

          {/* Template Selection */}
          <div className="p-6 border-b border-neutral-200">
            <h3 className="font-semibold text-secondary mb-4">Template</h3>
            <TemplateSelector
              selectedTemplate={selectedTemplate}
              onSelectTemplate={setSelectedTemplate}
              compact
            />
          </div>

          {/* Publishing Status */}
          <div className="p-6 border-b border-neutral-200">
            <h3 className="font-semibold text-secondary mb-4">Publishing</h3>
            {!isProActive ? (
              <Card className="bg-orange-50 border-orange-200">
                <CardContent className="p-4">
                  <div className="flex items-center text-sm">
                    <Rocket className="text-orange-500 mr-2 h-4 w-4" />
                    <span className="text-orange-700">Pro plan required to publish</span>
                  </div>
                  <Button size="sm" className="w-full mt-3" onClick={() => setLocation('/')}>
                    Upgrade to Pro
                  </Button>
                </CardContent>
              </Card>
            ) : !domain.endsWith('.ind') ? (
              <Card className="bg-red-50 border-red-200">
                <CardContent className="p-4">
                  <div className="flex items-center text-sm">
                    <Rocket className="text-red-500 mr-2 h-4 w-4" />
                    <span className="text-red-700">Only .ind domains can be published</span>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-green-50 border-green-200">
                <CardContent className="p-4">
                  <div className="flex items-center text-sm">
                    <Rocket className="text-green-500 mr-2 h-4 w-4" />
                    <span className="text-green-700">Ready to publish</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Page Elements */}
          <div className="p-6">
            <h3 className="font-semibold text-secondary mb-4">Add Elements</h3>
            <div className="space-y-2">
              <Button variant="ghost" className="w-full justify-start">
                <Heading className="w-4 h-4 mr-3" />
                Header
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <FileText className="w-4 h-4 mr-3" />
                Text Block
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Image className="w-4 h-4 mr-3" />
                Image
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <MousePointer className="w-4 h-4 mr-3" />
                Button
              </Button>
            </div>
          </div>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 p-8 bg-neutral-100">
          <Card className="bg-white shadow-lg min-h-96">
            <CardContent className="p-8">
              {/* Website Preview Content */}
              <div className="text-center space-y-6">
                <div className="w-20 h-20 bg-primary/20 rounded-full mx-auto flex items-center justify-center">
                  <div className="text-primary text-2xl font-bold">
                    {title.charAt(0) || "S"}
                  </div>
                </div>
                <h1 className="text-3xl font-bold text-secondary">
                  {title || "Your Site Title"}
                </h1>
                <p className="text-lg text-neutral-500">
                  {description || "Your site description will appear here"}
                </p>
                <div className="flex justify-center space-x-4">
                  <Button>Call to Action</Button>
                  <Button variant="outline">Learn More</Button>
                </div>
              </div>
              
              {/* Content Blocks */}
              <div className="mt-16">
                <h2 className="text-2xl font-bold text-secondary text-center mb-8">
                  Featured Content
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="bg-neutral-100 rounded-lg h-48 flex items-center justify-center">
                    <span className="text-neutral-500">Content Block 1</span>
                  </div>
                  <div className="bg-neutral-100 rounded-lg h-48 flex items-center justify-center">
                    <span className="text-neutral-500">Content Block 2</span>
                  </div>
                  <div className="bg-neutral-100 rounded-lg h-48 flex items-center justify-center">
                    <span className="text-neutral-500">Content Block 3</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
