import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertSiteSchema, insertSubscriptionSchema, insertPaymentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get user subscription
      const subscription = await storage.getUserSubscription(userId);
      
      res.json({
        ...user,
        subscription: subscription || { status: "inactive", planType: "free" }
      });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Site management routes
  app.get("/api/sites", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const sites = await storage.getUserSites(userId);
      res.json(sites);
    } catch (error) {
      console.error("Error fetching sites:", error);
      res.status(500).json({ message: "Failed to fetch sites" });
    }
  });

  app.post("/api/sites", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const siteData = insertSiteSchema.parse({ ...req.body, userId });
      
      // Validate .ind domain
      if (!siteData.domain.endsWith('.ind')) {
        return res.status(400).json({ message: "Only .ind domains are allowed" });
      }
      
      // Check if domain already exists
      const existingSite = await storage.getSiteByDomain(siteData.domain);
      if (existingSite) {
        return res.status(400).json({ message: "Domain already exists" });
      }
      
      const site = await storage.createSite(siteData);
      res.json(site);
    } catch (error) {
      console.error("Error creating site:", error);
      res.status(400).json({ message: "Failed to create site" });
    }
  });

  app.put("/api/sites/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const siteId = parseInt(req.params.id);
      
      // Verify site ownership
      const site = await storage.getSite(siteId);
      if (!site || site.userId !== userId) {
        return res.status(404).json({ message: "Site not found" });
      }
      
      const updates = req.body;
      
      // If publishing, check Pro status and domain validation
      if (updates.isPublished || updates.isActive) {
        const subscription = await storage.getUserSubscription(userId);
        if (!subscription || subscription.status !== "active") {
          return res.status(403).json({ message: "Pro plan required to publish sites" });
        }
        
        if (!site.domain.endsWith('.ind')) {
          return res.status(400).json({ message: "Only .ind domains can be published" });
        }
      }
      
      const updatedSite = await storage.updateSite(siteId, updates);
      res.json(updatedSite);
    } catch (error) {
      console.error("Error updating site:", error);
      res.status(400).json({ message: "Failed to update site" });
    }
  });

  app.delete("/api/sites/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const siteId = parseInt(req.params.id);
      
      const site = await storage.getSite(siteId);
      if (!site || site.userId !== userId) {
        return res.status(404).json({ message: "Site not found" });
      }
      
      await storage.deleteSite(siteId);
      res.json({ message: "Site deleted successfully" });
    } catch (error) {
      console.error("Error deleting site:", error);
      res.status(500).json({ message: "Failed to delete site" });
    }
  });

  // Template routes
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getAllTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  // Subscription routes
  app.get("/api/subscription", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const subscription = await storage.getUserSubscription(userId);
      res.json(subscription || { status: "inactive", planType: "free" });
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  app.post("/api/subscription/upgrade", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Mock Bitcoin payment creation - in real implementation would integrate with BTCPay Server
      const mockBtcAddress = "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh";
      const paymentAmount = "0.00001"; // $1 in BTC (mocked)
      
      // Create or update subscription
      let subscription = await storage.getUserSubscription(userId);
      
      if (subscription) {
        subscription = await storage.updateSubscription(subscription.id, {
          status: "pending",
          planType: "pro",
          btcAddress: mockBtcAddress,
          paymentAmount,
          nextBillingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        });
      } else {
        subscription = await storage.createSubscription({
          userId,
          status: "pending",
          planType: "pro",
          btcAddress: mockBtcAddress,
          paymentAmount,
          nextBillingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        });
      }
      
      // Create payment record
      await storage.createPayment({
        userId,
        subscriptionId: subscription.id,
        amount: paymentAmount,
        status: "pending",
        btcAddress: mockBtcAddress,
      });
      
      res.json({
        subscription,
        paymentInfo: {
          btcAddress: mockBtcAddress,
          amount: paymentAmount,
          qrCode: `bitcoin:${mockBtcAddress}?amount=${paymentAmount}`,
        }
      });
    } catch (error) {
      console.error("Error upgrading subscription:", error);
      res.status(500).json({ message: "Failed to upgrade subscription" });
    }
  });

  // Mock payment confirmation - in real implementation this would be a webhook from BTCPay Server
  app.post("/api/subscription/confirm-payment", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const subscription = await storage.getUserSubscription(userId);
      
      if (subscription && subscription.status === "pending") {
        await storage.updateSubscription(subscription.id, {
          status: "active",
          lastPaymentDate: new Date(),
        });
        
        res.json({ message: "Payment confirmed, Pro plan activated!" });
      } else {
        res.status(400).json({ message: "No pending subscription found" });
      }
    } catch (error) {
      console.error("Error confirming payment:", error);
      res.status(500).json({ message: "Failed to confirm payment" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const stats = await storage.getUserStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get("/api/admin/users", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/sites", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const sites = await storage.getAllSites();
      res.json(sites);
    } catch (error) {
      console.error("Error fetching sites:", error);
      res.status(500).json({ message: "Failed to fetch sites" });
    }
  });

  app.get("/api/admin/payments", isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const payments = await storage.getAllPayments();
      res.json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  // Domain validation route
  app.post("/api/validate-domain", async (req, res) => {
    try {
      const { domain } = req.body;
      
      if (!domain.endsWith('.ind')) {
        return res.json({ 
          valid: false, 
          message: "Only .ind domains are allowed" 
        });
      }
      
      const existingSite = await storage.getSiteByDomain(domain);
      if (existingSite) {
        return res.json({ 
          valid: false, 
          message: "Domain already taken" 
        });
      }
      
      res.json({ 
        valid: true, 
        message: "Domain available" 
      });
    } catch (error) {
      console.error("Error validating domain:", error);
      res.status(500).json({ message: "Failed to validate domain" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
